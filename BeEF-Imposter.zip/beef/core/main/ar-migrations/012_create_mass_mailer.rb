class CreateMassMailer < ActiveRecord::Migration[6.0]

	def change

		create_table :mass_mailer do |t|
            #todo fields
		end

	end

end
